

Data={'1FertilityS','2LymphographyS','3IrisS','4WineS','5PlanningRelaxS','6ParkinsonsS','7ConnectionistBenchS','8seedsS','9GlassIdentificationS','10AlgerianForestFiresS','11Climate_Model_Simulation_CrashesS','12BalanceScaleS','13BanknoteAuthenticationS','14WirelessIndoorLocalizationS'};
for i=1:length(Data)
    para=optpara_clear(Data{i},'rbf');
    Reture_err=Evaluation_clear(Data{i},para,'rbf');
end
