function index=BOCSVC_test(ker,p,alpha,b,X_train,X_test,Y_test)
[l,~]=size(X_test);
[n,~]=size(X_train);

K=zeros(n,l);
for i=1:n
    for j=1:l
K(i,j) = svkernel(ker,X_train(i,:),X_test(j,:),p);
    end
end
Y_pre=sign(K'*alpha+ones(l,1)*b-1);
acc=sum(Y_pre==Y_test)/l;
err=1-acc;
TP=sum(Y_test==1&Y_pre==1); FP=sum(Y_test==-1&Y_pre==1);
FN=sum(Y_test==1&Y_pre==-1); TN=sum(Y_test==-1&Y_pre==-1);
Spec=TN/(TN+FP+1e-10);
Rec=TP/(FN+TP+1e-10);
Prec=TP/(FP+TP+1e-10);
F_score=2*Rec*Prec/(Rec+Prec+1e-10);
G_mean=sqrt(Rec*Spec);
index=[acc,err,F_score,G_mean];