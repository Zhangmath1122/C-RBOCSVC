function split_data(Data)
[NameofDataSet,K]=Data{:}; 
load(NameofDataSet);
Xp=X(Y==1,:);Xn=X(Y==-1,:);
Np=size(Xp,1);Nn=size(Xn,1);
for ii=1:K
Xp=Xp(randperm(Np),:);Xn=Xn(randperm(Nn),:);
X_para= [Xp(1:round(Np*0.2),:);Xn(1:round(Nn*0.45),:)];
Y_para= [ones(round(Np*0.2),1);-ones(round(Nn*0.45),1)];

 Xt= [Xp((round(Np*0.2)+1):(round(Np*0.2)+round(Np*0.6)),:);Xn((round(Nn*0.45)+1):(round(Nn*0.45)+round(Nn*0.1)),:)];
 Yt=[ones(round(Np*0.6),1);-ones(round(Nn*0.1),1)];

Nvp=Np-round(Np*0.2)-round(Np*0.6); Nvn=Nn-round(Nn*0.45)-round(Nn*0.1);
Xv= [Xp((end-Nvp+1):end,:);Xn((end-Nvn+1):end,:)];
Yv=[ones(Nvp,1);-ones(Nvn,1)];

eval(['save ',NameofDataSet,'Train',num2str(ii),' X_para Y_para Xt Xv Yt Yv']);
end