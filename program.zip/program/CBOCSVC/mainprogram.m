function mainprogram(ker)

% para=optpara(ker,{'1',5});
% Reture_err=Evaluation({'1',5},ker,para);
 
para=optpara(ker,{'2',5});
Reture_err=Evaluation({'2',5},ker,para);

% para=optpara(ker,{'3',5});
% Reture_err=Evaluation({'3',5},ker,para);

para=optpara(ker,{'4',5});
Reture_err=Evaluation({'4',5},ker,para);

para=optpara(ker,{'5',5});
Reture_err=Evaluation({'5',5},ker,para);

% para=optpara(ker,{'6',5});
% Reture_err=Evaluation({'6',5},ker,para);

para=optpara(ker,{'7',5});
Reture_err=Evaluation({'7',5},ker,para);

para=optpara(ker,{'8',5});
Reture_err=Evaluation({'8',5},ker,para);

para=optpara(ker,{'9',5});
Reture_err=Evaluation({'9',5},ker,para);

para=optpara(ker,{'10',5});
Reture_err=Evaluation({'10',5},ker,para);

para=optpara(ker,{'11',5});
Reture_err=Evaluation({'11',5},ker,para);

para=optpara(ker,{'12',5});
Reture_err=Evaluation({'12',5},ker,para);

para=optpara(ker,{'13',5});
Reture_err=Evaluation({'13',5},ker,para);

% para=optpara(ker,{'14',5});
% Reture_err=Evaluation({'14',5},ker,para);

para=optpara(ker,{'15',5});
Reture_err=Evaluation({'15',5},ker,para);

para=optpara(ker,{'16',5});
Reture_err=Evaluation({'16',5},ker,para);

% para=optpara(ker,{'17',5});
% Reture_err=Evaluation({'17',5},ker,para);
% 
% para=optpara(ker,{'18',5});
% Reture_err=Evaluation({'18',5},ker,para);

para=optpara(ker,{'19',5});
Reture_err=Evaluation({'19',5},ker,para);

% para=optpara(ker,{'20',5});
% Reture_err=Evaluation({'20',5},ker,para);

para=optpara(ker,{'21',5});
Reture_err=Evaluation({'21',5},ker,para);