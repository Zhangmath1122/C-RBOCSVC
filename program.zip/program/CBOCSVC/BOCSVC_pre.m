function [alpha,b]=BOCSVC_pre(C,p,ker,X)
[n,~]=size(X);
K = zeros(n,n);  
    for i=1:n
       for j=1:n
          K(i,j) = svkernel(ker,X(i,:),X(j,:),p);
       end
 end
I=ones(n);
H=K+I;
H = H+(1e-6)*eye(n);
H=0.5*(H+H');
e=ones(n,1);
lb=zeros(n,1);
ub=C*e;
alpha = quadprog(H,-e,[],[],[],[],lb,ub);
b=e'*alpha;