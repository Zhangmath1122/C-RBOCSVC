function Reture_err=Evaluation_clean(Data,para,ker)
%%Data={'Gausample',K};
%  eval(['load ',Data{1},'Para']);
load(Data)
[C,p]=para{:};
tic;
err=zeros(5,4);
for j=1:5
          
%% MEBOCSVC
[alpha,b]=BOCSVC_pre(C,p,ker,Xt{j});
output=BOCSVC_test(ker,p,alpha,b,Xt{j},Xts{j},Yts{j});
err(j,:)=output;
end
alltime=toc;
time_mean=alltime/5;
err_mean=mean(err,1);                   
err_var=std(err,1);
Reture_err={err_mean,err_var,time_mean};
eval(['save ',Data,'evaluation',' err_mean err_var time_mean']); 