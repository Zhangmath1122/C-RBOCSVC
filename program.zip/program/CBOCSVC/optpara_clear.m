function para=optpara_clear(Data,ker)
%Data={'dataname',K};
load(Data);

%h = mean(pdist(X));
S_C=2.^(-10:1:10);   
%S_p=[0.1*h,h,10*h];
S_p=2.^(-10:1:10); 
scope={S_C,S_p};

CP = Train_Test_Map(scope);
err=zeros(length(CP),1);
for i=1:length(CP)
      paras =CP{i};
     [C,p]=paras{:};
     errs=0;
for j=1:5
%% MEBOCSVC
[alpha,b]=BOCSVC_pre(C,p,ker,Xt{j});
output=BOCSVC_test(ker,p,alpha,b,Xt{j},Xpa{j},Ypa{j});
errs=errs+output(2);  
end
err(i,1)=errs/5;
end
[~,index]=min(err);
para=CP{index};

eval(['save ',Data,'Para para']);