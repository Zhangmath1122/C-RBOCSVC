function Reture_err=Evaluation(Data,ker,para)
%%Data={'Gausample',K};
%  eval(['load ',Data{1},'Para']);
[C,p,K]=para{:};
tic;
err=zeros(Data{2},4);
for j=1:Data{2}
    eval(['load ',Data{1},'Train',num2str(j)]);
          
%% MEBOCSVC
[alpha,b]=RBOCSVC_pre(C,p,K,ker,Xt);
output=RBOCSVC_test(ker,p,alpha,b,Xt,Xv,Yv);
err(j,:)=output;
end
alltime=toc;
time_mean=alltime/Data{2};
err_mean=mean(err,1);                   
err_var=std(err,1);
Reture_err={err_mean,err_var,time_mean};
eval(['save ',Data{1},'evaluation',' err_mean err_var time_mean']); 