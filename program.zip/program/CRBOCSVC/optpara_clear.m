function para=optpara_clear(Data,ker)
%Data={'dataname',K};
load(Data);

%h = mean(pdist(X));
S_C=2.^(-7:1:7);   
%S_p=[0.1*h,h,10*h];
S_p=2.^(-7:1:7);
S_K=1:2:20;
scope={S_C,S_p,S_K};

CP = Train_Test_Map(scope);
err=zeros(length(CP),1);
for i=1:length(CP)
      paras =CP{i};
     [C,p,K]=paras{:};
     errs=0;
for j=1:5
%% MEBOCSVC
[alpha,b]=RBOCSVC_pre(C,p,K,ker,Xt{j});
output=RBOCSVC_test(ker,p,alpha,b,Xt{j},Xpa{j},Ypa{j});
errs=errs+output(2);  
end
err(i,1)=errs/5;
end
[~,index]=min(err);
para=CP{index};

eval(['save ',Data,'Para para']);