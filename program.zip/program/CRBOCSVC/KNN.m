function tau = KNN(ker,X,K,p1,p)
% index = Y==1;  
% X = X(index,:);
[l,~]=size(X);
dist=zeros(l,l);
for i=1:l    
    for j=1:l
%         dist(i,j)= svkernel(ker,X(i,:),X(i,:),p1)+svkernel(ker,X(j,:),X(j,:),p1)-2*svkernel(ker,X(i,:),X(j,:),p1);
% dist(i,j)=norm(X(i,:)-X(j,:),2);        
dist(i,j)=sqrt(svkernel(ker,X(i,:),X(i,:),p)+svkernel(ker,X(j,:),X(j,:),p)-2*svkernel(ker,X(i,:),X(j,:),p));
%         dist(i,j)=1-(1/(sqrt((2*pi)^m)*p1))*exp((-1/(2*p1))*norm(X(i,:)-X(j,:),2)^2); 
    end 
end
Y=sort(dist,2); 
d = Y(:,2:K+1); 
maxd = d(:,end);
maxY = Y(:,end);
tau = exp(-p1*((maxd.^2)./(maxY.^2)));
end