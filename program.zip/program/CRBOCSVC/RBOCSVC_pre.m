function [alpha,b]=RBOCSVC_pre(C,p,K,ker,X)
% tau=GRPS(X,ker,1,p);
%tic;
tau = KNN(ker,X,K,50,p);
[n,~]=size(X);
K = zeros(n,n);  
    for i=1:n
       for j=1:n
          K(i,j) = svkernel(ker,X(i,:),X(j,:),p);
       end
 end
I=ones(n);
H=K+I;
H = H+(1e-5)*eye(n);
H=0.5*(H+H');
e=ones(n,1);
lb=zeros(n,1);
ub=C*tau;
alpha = quadprog(H,-e,[],[],[],[],lb,ub);
b=e'*alpha;
%time=toc