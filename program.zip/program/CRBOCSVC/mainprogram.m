function mainprogram(ker)

Data={'1Fertility','2Lymphography','3Iris','4Wine','5PlanningRelax','6Parkinsons','7ConnectionistBench','8seeds','9GlassIdentification','10AlgerianForestFires','11Climate_Model_Simulation_Crashes','12BalanceScale','13BanknoteAuthentication','14WirelessIndoorLocalization'};

for i=1:length(Data)
para=optpara(ker,{Data{i},5});
Reture_err=Evaluation({Data{i},5},ker,para);
end